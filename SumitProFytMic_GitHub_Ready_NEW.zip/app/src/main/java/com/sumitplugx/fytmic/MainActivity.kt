package com.sumitplugx.fytmic

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private var recording = false
    private var recorder: AudioRecord? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(android.graphics.Color.rgb(45, 12, 55))
        }
        val title = TextView(this).apply {
            text = "SUMIT PLUGX\nSumit Pro Fyt Mic"
            textSize = 28f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Mic Test: Ready"
            textSize = 20f
            setTextColor(android.graphics.Color.WHITE)
            gravity = android.view.Gravity.CENTER
            setPadding(0, 50, 0, 50)
        }
        val mic = Button(this).apply {
            text = "🎙 Start Mic Test"
            setOnClickListener { toggleMic() }
        }
        val effects = Button(this).apply {
            text = "Voice Effects"
            setOnClickListener { status.text = "Voice Effects\nNormal • Deep • Echo • Robot" }
        }
        val fyt = Button(this).apply {
            text = "121 Call Fyt (Demo)"
            setOnClickListener { status.text = "121 Call Fyt\nDemo interface only" }
        }
        root.addView(title)
        root.addView(status)
        root.addView(mic)
        root.addView(effects)
        root.addView(fyt)
        setContentView(root)
    }

    private fun toggleMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        if (!recording) {
            val min = AudioRecord.getMinBufferSize(44100, 16, 2)
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, 44100, 16, 2, min)
            recorder?.startRecording()
            recording = true
            status.text = "Mic Test: ON\nMicrophone is active"
        } else {
            recorder?.stop()
            recorder?.release()
            recorder = null
            recording = false
            status.text = "Mic Test: Ready"
        }
    }

    override fun onDestroy() {
        recorder?.release()
        recorder = null
        super.onDestroy()
    }
}
